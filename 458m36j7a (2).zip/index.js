const num1 = Math.ceil(Math.random()*10)
const num2 = Math.ceil(Math.random()*50)

const questionE1 = document.getElementById("question");

const form = document.getElementById("input")

const formE1 = document.getElementById("form")

const inputE1 = document.getElementById("answer")

const scoreE1 = document.getElementById("score")

let score = JSON.parse(localStorage.getItem("score"));

if (!score) {
  score = 0;
}

scoreE1.innerText = `score: ${score}`

questionE1.innerText = `What is ${num1} multiply by ${num2}?`

const correctAns = num1*num2;

formE1.addEventListener("submit", ()=>{
    const userAns = Number (inputE1.value)
    if (userAns === correctAns){
      score++;
      updateLocalStorage()
    } else{
      score--;
      updateLocalStorage()
    }
})

function updateLocalStorage(){
  localStorage.setItem("score", JSON.stringify(score))
}
